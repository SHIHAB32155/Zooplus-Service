package com.service.zooplus.service;


import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class ServiceApplication {

    public static void main(String[] args) {

       // SpringApplication.run(ServiceApplication.class, args);

        try {

            Client client = Client.create();
            WebResource webResource = client.resource("http://api.nbp.pl/api/exchangerates/rates/c/usd/today/");

            ClientResponse web = webResource.accept("application/json").get(ClientResponse.class);

            if (web.getStatus() != 200) {
                throw new RuntimeException("Wrong HTTP .... " + web.getStatus());
            }

            String json = web.getEntity(String.class);
            System.out.println(json);

        } catch (Exception e){
            e.printStackTrace();
        }
    }

}
